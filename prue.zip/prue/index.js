const leader=document.getElementById("leader")
leader.addEventListener("click", ()=>{
    window.location.href='leader.html';
})

const brief=document.getElementById("brief")
brief.addEventListener("click", ()=>{
    window.location.href='index.html';
})
const setting=document.getElementById("setting")
setting.addEventListener("click", ()=>{
    window.location.href='setting.html';
})
const council=document.getElementById("council")
council.addEventListener("click", ()=>{
    window.location.href='council.html';
})